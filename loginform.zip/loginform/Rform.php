
<!DOCTYPE HTML>  
<html>
<head>
<style>
.error {color: #FF0000;}
.form-group {
  margin-bottom: 2px;
  margin-left: 2px;
}
</style>
</head>
<body>  

<?php
// define variables and set to empty values
$nameErr = $emailErr = $genderErr  =  $fathernameErr = $CNICErr = $addressErr = "";
$name = $fathername = $CNIC = $address =  $email = $gender =  "";

if ($_SERVER["REQUEST_METHOD"] == "POST") {
  if (empty($_POST["name"])) {
    $nameErr = "";
  } else {
    $name = test_input($_POST["name"]);
  }
  
  if (empty($_POST["fathername"])) {
    $fathernameErr = "";
  } else {
    $fathername = test_input($_POST["fathername"]);
  }
    
  if (empty($_POST["CNIC"])) {
    $CNICErr = "";
  } else {
    $CNIC = test_input($_POST["CNIC"]);
  }

  if (empty($_POST["address"])) {
    $addressErr = "";
  } else {
    $address = test_input($_POST["address"]);
  }
  if (empty($_POST["email"])) {
    $emailErr = "";
  } else {
    $email = test_input($_POST["email"]);
  }
    

  if (empty($_POST["gender"])) {
    $genderErr = "";
  } else {
    $gender = test_input($_POST["gender"]);
  }
}

function test_input($data) {
  $data = trim($data);
  $data = stripslashes($data);
  $data = htmlspecialchars($data);

  return $data;
}
?>
<center>
<h1>___________Registration Form_____________</h1>
<p><span class="error"></span></p>
<form method="post" action="<?php echo htmlspecialchars($_SERVER["PHP_SELF"]);?>">  
  <div class="form-group">
  <strong>Name:</strong><input type="text" name="name">
  <span class="error"> <?php echo $nameErr;?></span>
  <br><br>
</div>
<div class="form-group">
  <strong>Fathername:</strong><input type="text" name="fathername">
  <span class="error"> <?php echo $fathernameErr;?></span>
  <br><br>
</div>
<div class="form-group">
  <strong>CNIC: </strong><input type="numbers" name="CNIC">
  <span class="error"><?php echo $CNICErr;?></span>
  <br><br>
</div>
<div class="form-group">
  <strong>Address:</strong><input type="text" name="address">
  <span class="error"><?php echo $addressErr;?></span>
  <br><br>
</div>
<div class="form-group">
  <strong>E-mail:</strong><input type="text" name="email">
  <span class="error"> <?php echo $emailErr;?></span>
  <br><br>
</div>
<div class="form-group">
  <strong>Gender:</strong>
  <input type="radio" name="gender" value="female">Female
  <input type="radio" name="gender" value="male">Male
  <input type="radio" name="gender" value="other">Other
  <span class="error"> <?php echo $genderErr;?></span>
  <br><br>
</div>
           <input type="submit" name="submit" value="Submit">  
</form>

<?php
echo "<h1> Input is:</h1>";
echo $name;
echo "<br>";
echo $fathername;
echo "<br>";
echo $CNIC;
echo "<br>";
echo $address;
echo "<br>";
echo $email;
echo "<br>";
echo $gender;
?>
</center>
</body>
</html>
