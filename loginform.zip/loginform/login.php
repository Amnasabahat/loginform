<html>
<body>
<center>
   <h1>_______________LOGIN________________</h1>
<form action="Rform.php "  method="POST"style="margin-top: 20px;"  onsubmit="return validateform()">
 <label for="Username">Username:</label>
<input  type="text" id="Username"  name="Username"><br><br>
 <label for="pwd">Password:</label>
<input  type="password" id="pwd" name="pwd"  minlength="8"><br><br>
<input  type="submit" name="submit">
</form>
</center>
</body>
</html>
